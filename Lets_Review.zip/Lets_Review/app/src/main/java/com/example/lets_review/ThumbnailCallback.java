package com.example.lets_review;

import com.zomato.photofilters.imageprocessors.Filter;

public interface ThumbnailCallback {
    void onThumbnailClick(Filter filter);
}
