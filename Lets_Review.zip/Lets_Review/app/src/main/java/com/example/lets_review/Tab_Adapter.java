package com.example.lets_review;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class Tab_Adapter extends FragmentPagerAdapter {
    int No_Of_Tab;

    public Tab_Adapter(FragmentManager fm, int tabCount) {
        super(fm);

        this.No_Of_Tab = tabCount;

    }

    @Override
    public Fragment getItem(int i) {
        return  null;
    }

    @Override
    public int getCount() {
        return No_Of_Tab;
    }
}
